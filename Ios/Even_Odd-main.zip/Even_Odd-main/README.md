# Even-Odd
## _An ios app for checking Even Odd Numbers_
Used UIelements
- UITextField
- UIButton
- UILabel
## Working
- Simple First page have button for go inside Application
- ON clicking that move next page which have UITextField and UIButton
- If user Entered Anything else accept Numbers It will Not allow
- Then click on check Button It redirect on Result Page
- Result Shown In label
## Features
- Very simple App For Using
- It's USer Freiendly
- animated page and fabulous UIdesign
